from ultralytics import YOLO
import cv2
import time

# Cargar el modelo YOLO entrenado
model = YOLO("best.pt")

# Captura desde la cámara IMX500 (como webcam estándar)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("❌ No se pudo acceder a la cámara.")
    exit()

print("✅ Cámara iniciada. Presiona Ctrl+C para detener.\n")

try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("⚠️ No se pudo leer el frame.")
            break

        # Detección
        results = model(frame)

        # Obtener información de detecciones
        boxes = results[0].boxes
        names = model.names  # Diccionario: id -> nombre de clase

        # Si hay detecciones, mostrar resultados
        if len(boxes) > 0:
            print("🟩 Detecciones:")
            for box in boxes:
                cls_id = int(box.cls[0])         # ID de clase
                conf = float(box.conf[0])        # Confianza
                x1, y1, x2, y2 = box.xyxy[0]     # Coordenadas

                print(f"  - Clase: {names[cls_id]} | Confianza: {conf:.2f}")
                print(f"    Coordenadas: ({int(x1)}, {int(y1)}) → ({int(x2)}, {int(y2)})")

        else:
            print("🕳️ Sin detecciones.")

        # Esperar un poco (para no saturar la CPU)
        time.sleep(0.5)

except KeyboardInterrupt:
    print("\n🛑 Detección detenida por el usuario.")

cap.release()
